First compile the server.c and client.c files in serparate terminal windows

    gcc server.c -o server

    gcc client.c -o client

then run the server first and then run the client

    ./server

    ./client

Messaging will start from client to server.